import sys,codecs
fout=codecs.open("errors.log",'w',encoding='UTF-8')
fout.write('')
fout.close()
fout=codecs.open("errors.log",'a',encoding='UTF-8')
def printf(txt):
	print(txt)
	fout.write("%s\n"%txt)
def ckNumb(strIn):
	for item in strIn.split(','):
		try: 
			float(item.strip())
			return True
		except: pass
	return False
printf("%sPlant Identifyer Tool - Usibility tester\n09 July 2012 by Matthew O'Toole for Plant Identifyer Software.\nEnter filename below or as an arguement in the comandline. Path may be relative.\n%s\n"%("*"*50,"*"*50))
if len(sys.argv)>1:
	filename=sys.argv[1]
else:
	filename=input("Enter a file name to test: \a")
if filename.split(".")[-1]!='csv' or len(filename)<5:
	printf("Not a csv file. Test terminated!")
	quit()
else:
	printf("Starting Test for file: %s"%filename)
	tfin=codecs.open(filename,encoding='UTF-8')
	cfin=codecs.open("../Chars.csv",encoding='UTF-8')
	cChars={}
	for line in cfin:
		if line.split('\t')[0] in ('Dbl','Clr','Gdd','Int','Mlt'):
			try: cChars[line.split('\t')[1].strip()]=[item.strip() for item in line.split('\t')[2].split(',')]
			except: 
				printf("Chars.csv file contains errors. Correct these first, then try again\nTest Terminated!")
				quit()
	i=0
	misc=False
	for line in tfin:
		if "Misc" in line: misc=True
		i+=1
		if '#' not in line:
			if len(line)<2: printf("Empty line found. This is OK")
			else:
				if len(line.split('\t'))<2: printf("Critical Error! Line number %i seems to be missing a tab (%s)"%(i,line))
				elif line.split('\t')[0] not in cChars and not misc: 
					if line.split('\t')[0].title() in cChars: printf("Error, mistake with capitalisation on line %i: %s should be %s"%(i,line,line.split('\t')[0].title()+line.split('\t')[1].lower()))
					else:printf("Character %s, on line %i, doesn't appear to be in the Chars.csv file. Spelling mistake?"%(line.split('\t')[0],i))
				elif not misc and not ckNumb(line.split('\t')[1]):
					for item in line.split('\t')[1].split(','):
						if item.strip() not in cChars[line.split('\t')[0]]: 
							if item.strip().lower() in cChars[line.split('\t')[0]]: printf("Error in character option capitilisation. It should always be lower case. Line %i: %s"%(i,line))
							else:printf("Error option %s found on line %i (%s) is not found in Chars.csv. Check spelling or consider adding it"%(item.strip(),i,line))
	if not misc: printf("Error: no #misc section found in the file. This could explain some of the errors above!!!")
	printf("Test finished. No (more) errors found.")
